-- phpMyAdmin SQL Dump
-- version 4.9.5deb1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 13, 2020 at 11:25 AM
-- Server version: 8.0.20-0ubuntu0.19.10.1
-- PHP Version: 7.3.19-1+ubuntu19.10.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `portal-api`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `login_requests`
--

CREATE TABLE `login_requests` (
  `id` bigint UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_used` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expired_at` timestamp NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `login_requests`
--

INSERT INTO `login_requests` (`id`, `email`, `token`, `is_used`, `created_at`, `updated_at`, `expired_at`) VALUES
(1, 'portal-user@gmail.com', '7e7d1ece59a27e14d57dc46c4ef1b6cb', 0, '2020-07-11 05:48:45', '2020-07-11 05:48:45', '2020-07-11 06:48:45'),
(2, 'portal-user@gmail.com', '85afe2412a656bb5e0a63be2cd695d59', 1, '2020-07-11 05:49:14', '2020-07-11 05:51:02', '2020-07-11 06:49:14'),
(3, 'portal-user@gmail.com', 'caab206b7c46494b0bc690352d26557b', 1, '2020-07-12 02:02:39', '2020-07-12 02:16:43', '2020-07-12 03:02:39'),
(4, 'portal-2user@gmail.com', '76abb0784b8c1d9e4065cb615f8062c6', 0, '2020-07-12 06:34:26', '2020-07-12 06:34:26', '2020-07-12 07:34:26'),
(5, 'portal-2user@gmail.com', '8605d6a2281cbdeb0c3b33a9d1c85be4', 0, '2020-07-12 06:34:29', '2020-07-12 06:34:29', '2020-07-12 07:34:29'),
(6, 'portal-2user@gmail.com', '61338cd8078da777c1397007509b3609', 0, '2020-07-12 06:36:58', '2020-07-12 06:36:58', '2020-07-12 07:36:58'),
(7, 'portal-2user@gmail.com', '0780ae798a3266898ecb2f254803f79f', 0, '2020-07-12 06:37:05', '2020-07-12 06:37:05', '2020-07-12 07:37:05'),
(8, 'portal-2user@gmail.com', 'a14a246936a65c75d1008c32eff413bd', 0, '2020-07-12 06:38:23', '2020-07-12 06:38:23', '2020-07-12 07:38:23'),
(9, 'portal-2user@gmail.com', '2ddfb185bf421392178b7adb7c6a2c89', 0, '2020-07-12 06:38:35', '2020-07-12 06:38:35', '2020-07-12 07:38:35'),
(10, 'portal-2user@gmail.com', '9839690ce3d209b6ed4920551edd35ec', 0, '2020-07-12 06:38:52', '2020-07-12 06:38:52', '2020-07-12 07:38:52'),
(11, 'portal-2user@gmail.com', '6c605b2468646d40926c3c2b7b9e3cb1', 1, '2020-07-12 06:51:03', '2020-07-12 06:57:45', '2020-07-12 07:51:03'),
(12, 'portal-user2@gmail.com', '81ba845143a3ee283f44ef30394b820d', 1, '2020-07-12 23:50:06', '2020-07-12 23:50:42', '2020-07-13 00:50:06');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(9, '2014_10_12_000000_create_users_table', 1),
(10, '2014_10_12_100000_create_password_resets_table', 1),
(11, '2016_06_01_000001_create_oauth_auth_codes_table', 1),
(12, '2016_06_01_000002_create_oauth_access_tokens_table', 1),
(13, '2016_06_01_000003_create_oauth_refresh_tokens_table', 1),
(14, '2016_06_01_000004_create_oauth_clients_table', 1),
(15, '2016_06_01_000005_create_oauth_personal_access_clients_table', 1),
(16, '2019_08_19_000000_create_failed_jobs_table', 1),
(19, '2020_07_11_073147_create_login_requests_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `client_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('0298c80f6f203efe853a91a6a99eb24315bc53ecdce770d2a2ef69bdfd03298fdbcbe4a77f3f1b72', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 07:38:57', '2020-07-12 07:38:57', '2021-07-12 13:08:57'),
('04125611d0f67bc95501b5db361ad13f2dd4163ff932485387b36328e729643fec76f68f3df03434', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 02:36:58', '2020-07-12 02:36:58', '2021-07-12 08:06:58'),
('0468f9acd2bdec127e0f309b27e4f45cc81abdee3d6ce6431e051a4d4e3e173ba410014779412250', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 06:57:45', '2020-07-12 06:57:45', '2021-07-12 12:27:45'),
('0bdda0907a21d42f1ddf06ae37d77eca157fd652e4c7f0c9111c01420b535a11219d2c0932ca527e', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 03:21:00', '2020-07-12 03:21:00', '2021-07-12 08:51:00'),
('0ef8ee838d0967ee96efb4bb6a0b535a668778397dcd67a3b3d50337a728c31506aa2f5de3b1d439', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 07:12:41', '2020-07-12 07:12:41', '2021-07-12 12:42:41'),
('115534814a9cb3a7f3f3fb8ba2352b5bb6bc138d7a13672ddf61fd3e88e61cdc0843c839d0c087d9', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 03:27:26', '2020-07-12 03:27:26', '2021-07-12 08:57:26'),
('139fe781b17226d1fa5fbdf93ce05ecd9f78ea33bdc6a95727b377e18e4b3d789a1127b706d45b11', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 03:18:20', '2020-07-12 03:18:20', '2021-07-12 08:48:20'),
('170bb8dd43e95cabb56f7024624bee2580b02b5f353f390001bc08cdffc6750e8951deab0997a2e6', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 05:52:16', '2020-07-12 05:52:16', '2021-07-12 11:22:16'),
('191d7f29dc920367ce2b933d489e0208754bd523372aea2e89b6443fbbcecc4bc0295d658d79cd2d', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 03:25:43', '2020-07-12 03:25:43', '2021-07-12 08:55:43'),
('1c4bfb1ed5987491130b3ea6367de7d3c3630c4362b8ea7753dbcc9a3e026a9c0ef818f6c5f1d6fc', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 03:21:49', '2020-07-12 03:21:49', '2021-07-12 08:51:49'),
('322f8d8908ad5fea1a0b49605433dadf73fc04d87a5c90b442e1271b521d637fc34fdd59d48edbcf', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 03:26:00', '2020-07-12 03:26:00', '2021-07-12 08:56:00'),
('32c40e5eb64afc2b6bdac7efdaae7f2c0f036ddf783c85de693adf38439af929cc36a9b19eda0f2b', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 03:25:18', '2020-07-12 03:25:18', '2021-07-12 08:55:18'),
('36654a5d7839589065f9f1e266e184ea3a416dd02b8472ad74e905a3ba0cfdfff0e7e63d45355ea6', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 02:54:36', '2020-07-12 02:54:36', '2021-07-12 08:24:36'),
('377b6b0d404d6c170137d3dacabc89a187f35eaefa03bb8b87a0425972543c80f90d081cbf1ef82b', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 02:23:23', '2020-07-12 02:23:23', '2021-07-12 07:53:23'),
('3800cc177aad5a3f6c231d664dd165655ed3581bdf44701458c61c9eb5d20731ab8ed2735693d8c3', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 02:40:29', '2020-07-12 02:40:29', '2021-07-12 08:10:29'),
('3c204381b4112ee63aeaf05b0b1a921a31a9604e0ea131804041ec31c989c9792850390196105066', 2, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 0, '2020-07-13 00:10:12', '2020-07-13 00:10:12', '2021-07-13 05:40:12'),
('3da8b8419b0da87c6ce3116ffbb864fb0f2a4899fe3c7c4da226829921315a3feee203ead7b47859', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Auth Token', '[]', 1, '2020-07-11 03:26:12', '2020-07-11 03:26:12', '2021-07-11 08:56:12'),
('3f5903c331ecdeeb1d7c404fdf2f7c0ecb28b657a29a66b0bd5af88b7048b942a30864df8e90d76d', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 03:16:01', '2020-07-12 03:16:01', '2021-07-12 08:46:01'),
('40981c605d0bce9a674de86540ecc6b918a5358811c1c2114cdf857a71defe3f5209eb1344011af8', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 02:19:40', '2020-07-12 02:19:40', '2021-07-12 07:49:40'),
('450084393045153c5138bdf5926ac7cb4be92cbc4a39a09f576eab219db32f7c9e4fa02f310aa443', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 0, '2020-07-12 07:41:54', '2020-07-12 07:41:54', '2021-07-12 13:11:54'),
('48268f77bd2f60f7e26097608664c6c3d307bb8a27b00aaf58cb8f5e328d64107f56c0df7be2966c', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-11 05:51:02', '2020-07-11 05:51:02', '2021-07-11 11:21:02'),
('49190570e315494dce0fc017744bf148694f18891c7a2d3e81f7c0373c34d95bb5a903143b8bb0b7', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 02:36:57', '2020-07-12 02:36:57', '2021-07-12 08:06:57'),
('49e944c06af7edabece59c0637eb80392b845db716cc39d9c6a1b97d66c992e5b1af6e56ee66423b', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 02:16:44', '2020-07-12 02:16:44', '2021-07-12 07:46:44'),
('51635993dcc5688e902d5ba1cc043fa2de23eacca7abeeb263fa6ec725f7552325d1265626d0e042', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Auth Token', '[]', 1, '2020-07-11 03:36:20', '2020-07-11 03:36:20', '2021-07-11 09:06:20'),
('585ac921025b2b0d626f8bf073c8ecea1add5c86d5e3e0038f9fbd0556835e53666aa206b6de3cab', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 02:17:34', '2020-07-12 02:17:34', '2021-07-12 07:47:34'),
('592ec71af6549fcc6f8f8814713bf9149c8dc218dd0b7c8978bd7867ad1605c5bfa00ab83882318d', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 02:19:50', '2020-07-12 02:19:50', '2021-07-12 07:49:50'),
('5aa1c035a3cdacfc381967eb474aa4522e319d536fe492e81a3211500c69e0ba5ede29f7c6332c48', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 03:10:20', '2020-07-12 03:10:20', '2021-07-12 08:40:20'),
('5b1f70892fdda93940e8690162e5be5523b79ce95ab77056eba23eab051b3d48d8af9ab7f3bc349b', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 03:18:46', '2020-07-12 03:18:46', '2021-07-12 08:48:46'),
('61f05e0fd0b2c5a536d8d7eb9e730bc870eca419cb9b3688a26b5be878bc916c3f8761bd41e1e584', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 03:13:40', '2020-07-12 03:13:40', '2021-07-12 08:43:40'),
('6427639c64e40bd217aa4e16affbb137a5ac795f7731485b81c4bcc45989015636e5ff6c85174c33', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 02:57:01', '2020-07-12 02:57:01', '2021-07-12 08:27:01'),
('67885c9a2d138231539b5a85b4bdc3b7e731743ed328922ac71b55e0c015721906f323c9841d7bec', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 03:02:57', '2020-07-12 03:02:57', '2021-07-12 08:32:57'),
('6bb0d511533ad236d8d17bc6042a1a81a1cdac0e0d9d140bff46aa2b6eaa7ff1680d99358dd0c62f', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 03:25:08', '2020-07-12 03:25:08', '2021-07-12 08:55:08'),
('6c41d2c0a3cc240bb6baf0130aad5bab1bf7929d4e9623361c85aca16d8eb5b82662a18ff41afbe5', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 03:27:29', '2020-07-12 03:27:29', '2021-07-12 08:57:29'),
('6df8f9da416219252d2d34256656fe59a12a933abd24806d7647b00fecf7bb9b35016797bda55107', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 02:48:57', '2020-07-12 02:48:57', '2021-07-12 08:18:57'),
('75a8534dd0c102b64e91ee3bd40c1363e2395c2f0a3131816be7921a12c7031c9ad8f5b517f05546', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 03:18:14', '2020-07-12 03:18:14', '2021-07-12 08:48:14'),
('796b0e69e6c4f9d954f429a66721269c4716ac4faadcd7f4e2ef117f2c87cac71aef5660a628ef5e', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Auth Token', '[]', 1, '2020-07-11 03:28:08', '2020-07-11 03:28:08', '2021-07-11 08:58:08'),
('86215f24748a539c72f10f446eee97ace606394c9b5c0de8e39525b6d4c21302db9405354a0ebdec', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 03:25:39', '2020-07-12 03:25:39', '2021-07-12 08:55:39'),
('8728f51d63d7e464d1164cb5040b1f54dbed1ce03e4e9e5de40443cc2646d6e526b7fff3da24db51', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 02:56:10', '2020-07-12 02:56:10', '2021-07-12 08:26:10'),
('8a6cf7d53110c2f6c8c9884ac6bf75c194e7235ae391a3ba2a4836730d93dc1a9def05ff7c53605b', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 03:12:08', '2020-07-12 03:12:08', '2021-07-12 08:42:08'),
('8c383a74b9d87335a71957068a611d72cb8518c3a2f3275609a1ca6f1cfaa80c7dc93f762241852c', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 03:46:31', '2020-07-12 03:46:31', '2021-07-12 09:16:31'),
('8e4fc382417817328dacb26f2cbaf30285fa7a23bb89257c4ae168e80517156b9936d5e18541301e', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 02:56:41', '2020-07-12 02:56:41', '2021-07-12 08:26:41'),
('98cb96748cf4a640312cd7a5cd0dcce61f2fb4293b74098ac501e4767b43652fe7da23f10056707a', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 03:17:59', '2020-07-12 03:17:59', '2021-07-12 08:47:59'),
('9f690476307b9909ea7f58d5f041406e5ad538c19df86575d30e712035157bce4571e27fdb7b418f', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 03:17:25', '2020-07-12 03:17:25', '2021-07-12 08:47:25'),
('a06c5a48426036cdb82df95ee0a8296b4d49c3c73c0dd92c1669e99aa436bd38689950436d302352', 2, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 23:50:42', '2020-07-12 23:50:42', '2021-07-13 05:20:42'),
('a1819ed2a49d4fceb658f61ddbe3dc4efb0fddd7eb707c41dce971b8632844cf38ca5eabfa877126', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 02:19:10', '2020-07-12 02:19:10', '2021-07-12 07:49:10'),
('a3d14ead905fb146de7133e492f73d24692890f306b0c807a9b1d524e2a1649ce84bc52c06ae1574', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 02:40:29', '2020-07-12 02:40:29', '2021-07-12 08:10:29'),
('b10f4eea8283ae51a9e681cfb51e4f864173f94cba00aac2043e2038a0603e7277b35dac9ba9bf01', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 07:33:48', '2020-07-12 07:33:48', '2021-07-12 13:03:48'),
('b25c3b3ad598661fef594be8e70add7be8b2d0546f185065123df27c1439afd2830b51392d106d13', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 02:36:00', '2020-07-12 02:36:00', '2021-07-12 08:06:00'),
('b2746963198fd851d84a0c5b1f276346900c9581667a3014ab33370716f62ca33fefb639027cb96c', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 07:33:40', '2020-07-12 07:33:40', '2021-07-12 13:03:40'),
('b3896924a1e0045f5ed459fb28c6473b8b8b429b16bc5366501da23500b773f43399a800da0f2fb8', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Auth Token', '[]', 1, '2020-07-11 03:26:38', '2020-07-11 03:26:38', '2021-07-11 08:56:38'),
('b7061cbc831b8b766b4cf11d9a10fe12a5952188141865611cc49379420deaa80cf13b864e81ae52', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 03:16:47', '2020-07-12 03:16:47', '2021-07-12 08:46:47'),
('b7e3b12eacfe0a9df075103e6595b64052bde0a01730ea8d0a9891c615dc8f2ea8c9b1ff6479a030', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 03:18:36', '2020-07-12 03:18:36', '2021-07-12 08:48:36'),
('bb5cf9d1a4593d54ff82e87b6dc5444f6e540da31f3e0250f5f426e46e8a2b31660de7166d7377bd', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 05:50:47', '2020-07-12 05:50:47', '2021-07-12 11:20:47'),
('bc96bf218c4f84df54e3e4e96384f6a684b83a397ce8c5f6d907a2f0b46d39cdbb98db3c1641a987', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Auth Token', '[]', 1, '2020-07-11 03:43:53', '2020-07-11 03:43:53', '2021-07-11 09:13:53'),
('c04f35f1933e2eec5a0d7090fd65d967bc14156b59cf5cce1202057feba124e2dc5686e5cedb83cd', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 02:57:26', '2020-07-12 02:57:26', '2021-07-12 08:27:26'),
('c96b87d1c11a1631e8069f020d9ba122ede9bcde1323235231610b2ed89de47cc05f09f958e57711', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 02:44:47', '2020-07-12 02:44:47', '2021-07-12 08:14:47'),
('cdf02edfb8df5d78a645b6a3e785b1ff262c20a4d24ba22a96541d0454f11cd8828455bea17d6471', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 03:18:57', '2020-07-12 03:18:57', '2021-07-12 08:48:57'),
('d71ab63019c8ae09e679e4114cefe873d64153ecc6506d44a6cae05c71838a580b10909bef0da8b8', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 03:16:44', '2020-07-12 03:16:44', '2021-07-12 08:46:44'),
('d9617b927645503f0f2b7713b940070ccb4521577eec0f94df7cb6dbe54971cfcdce13317690e824', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 05:40:48', '2020-07-12 05:40:48', '2021-07-12 11:10:48'),
('dfadc62fafb523a66097f8ed07f141d0dc8a9f1712e5798c86389959d3eb9c46dfd1816f5e299049', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 02:19:34', '2020-07-12 02:19:34', '2021-07-12 07:49:34'),
('dfc6e3576b698d2353254688bb921ac8659c200654e18b2272b9050f4622c506e2d326f4e519d18b', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-11 05:26:50', '2020-07-11 05:26:50', '2021-07-11 10:56:50'),
('e4ad130b926ff673560f48a975ff12e050ab5de1ada01c810d67226b4d97c1be07788c4156cda32d', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 02:56:12', '2020-07-12 02:56:12', '2021-07-12 08:26:12'),
('eb352cfdaeed59e23f15bccd5107ff698693407695a1db36f9d49655bc88071c2344653f374009e1', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 02:19:44', '2020-07-12 02:19:44', '2021-07-12 07:49:44'),
('ec52c93876d2f02de9908adc7be71cad478426a168242d238a21683dde7fbc246a7e700ad18e9211', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Auth Token', '[]', 1, '2020-07-11 03:26:40', '2020-07-11 03:26:40', '2021-07-11 08:56:40'),
('f14393a422c73b110180269ddbe32a7134fa582070c7f1b3e2bc143f6ab2d01d1fcef39a038f14f9', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 02:23:56', '2020-07-12 02:23:56', '2021-07-12 07:53:56'),
('fbf1c10667ab38d3fbdaeae008e30ce93793314ecfedf3444ef5b3d80766561b42fdcc09370f273f', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 03:02:01', '2020-07-12 03:02:01', '2021-07-12 08:32:01'),
('fcf4a4bb816391b42babd5ba5e9f3787f1c5620580332abefda866e181ae0d0be3499fcb3bc97cff', 1, '9103dce4-95b4-4416-8b3c-901cbd9d290d', 'Authentication Token', '[]', 1, '2020-07-12 02:53:03', '2020-07-12 02:53:03', '2021-07-12 08:23:03');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `client_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `provider`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
('9103dc5c-058f-4907-8fe2-aac28f2e5d56', 1, '1', '6tKtKo84fEc49CFxSlr1AeyvYwvzjx6aaAsnEopW', NULL, 'http://localhost/auth/callback', 0, 0, 0, '2020-07-11 03:24:39', '2020-07-11 03:24:39'),
('9103dce4-95b4-4416-8b3c-901cbd9d290d', NULL, 'Laravel Personal Access Client', 'P8rTT34U2BwGiAMfjmXu2cGThEFlwNOKtmunbj3x', NULL, 'http://localhost', 1, 0, 0, '2020-07-11 03:26:08', '2020-07-11 03:26:08'),
('9103dce5-29ff-4f4c-967a-89fdebf56624', NULL, 'Laravel Password Grant Client', '4oLwp8or56BKnfaGbZnorDmrEvJzsxTVjwgeO8tG', 'users', 'http://localhost', 0, 1, 0, '2020-07-11 03:26:09', '2020-07-11 03:26:09');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint UNSIGNED NOT NULL,
  `client_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, '9103b5df-8e4a-4d91-83cc-93c6de5148a7', '2020-07-11 01:37:03', '2020-07-11 01:37:03'),
(2, '9103dce4-95b4-4416-8b3c-901cbd9d290d', '2020-07-11 03:26:09', '2020-07-11 03:26:09');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('portal-user@gmail.com', '$2y$10$VzoC9qyt.vsosePR6Q6KJuqi1Ui1IBCYq8nuueHINdwGylFGmqXYS', '2020-07-11 05:02:08');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Portal User', 'portal-user@gmail.com', NULL, 'eyJpdiI6ImRJRkJkaVVMcUFSWjh1aUJhUkg2b3c9PSIsInZhbHVlIjoiVWR1NkRhSC9KUWNQREF5cW1qeFdEQT09IiwibWFjIjoiNDYzZGMxZjNjZjUzODY2NzBmOTIxNDAzMGUyN2RiNzdlMmY3NDRmMTVkZjYxY2E5MTc1NWZkZThmNWYxN2Q5YSJ9', NULL, NULL, NULL),
(2, 'Portal User2', 'portal-user2@gmail.com', NULL, 'eyJpdiI6IlBCWFZRTlF1aXB0dndkNENVeXF6V1E9PSIsInZhbHVlIjoialpMR0hVaVluTm1XRXVDMFZRWGthZz09IiwibWFjIjoiZTFmMDg1ZmQ5YWQ1NWRhODkzMGU4ODNhNzQxZDlkYTBlMmQxZGFjYjdiNTg1ODllZjUzMmFmMjBhNzI1ZmE1MCJ9', NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_requests`
--
ALTER TABLE `login_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `login_requests_email_index` (`email`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_auth_codes_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login_requests`
--
ALTER TABLE `login_requests`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
